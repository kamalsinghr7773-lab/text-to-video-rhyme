# Text to Video Rhyme Generator Template

## Folders
- frontend/index.html  → UI
- backend/server.js    → API backend

## How to use
1. Upload frontend folder to GitHub Pages.
2. Deploy backend to Vercel/Render.
3. Replace YOUR_BACKEND_URL in index.html.
